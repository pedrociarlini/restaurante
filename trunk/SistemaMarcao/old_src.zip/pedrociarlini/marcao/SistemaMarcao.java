package pedrociarlini.marcao;

import pedrociarlini.marcao.view.MainWindow;

public class SistemaMarcao {
	public static void main(String[] args) {
		MainWindow j = new MainWindow();
		j.setVisible(true);
	}
}
