package pedrociarlini.marcao.caixa.util;

public class CaixaMessages {
	/**
	 * TODO Usar MessageDoclet
	 */
	public static final String MSG_ERROR_INSERIR_TIPO_PAGAMENTO = "CAIXA_INS_TIPO_01";
}