package pedrociarlini.marcao.caixa.view.actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import pedrociarlini.marcao.actions.AbrirJanelaAction;
import pedrociarlini.marcao.caixa.view.JanelaFechamentoDeCaixa;

public class AbrirFechamentoDeCaixa extends AbrirJanelaAction {

}