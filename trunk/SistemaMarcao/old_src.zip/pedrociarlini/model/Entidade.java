package pedrociarlini.model;

import java.io.Serializable;


public class Entidade implements Serializable {

}
