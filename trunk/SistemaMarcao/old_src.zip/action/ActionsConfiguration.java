package action;

import java.util.HashMap;
import java.util.Map;


public class ActionsConfiguration {
    private Map actions = new HashMap();

    
    public Map getActions() {
        return actions;
    }
    
    public void setActions(Map actions) {
        this.actions = actions;
    }
    
    //public addAction("");
    
    
}
